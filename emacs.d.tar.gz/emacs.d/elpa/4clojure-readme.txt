To open a specific problem, use `4clojure-open-question':
e.g. "M-x 4clojure-open-question RET 2" opens question 2.

To check your answers, use `4clojure-check-answers':
e.g. `M-x 4clojure-check-answers`

To open the next question (or the first if you’re not in a 4clojure
buffer), use `4clojure-next-question'. Similarly,
`4clojure-previous-question' opens the previous question.
